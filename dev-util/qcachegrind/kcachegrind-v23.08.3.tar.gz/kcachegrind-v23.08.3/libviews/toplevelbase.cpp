/*
    This file is part of KCachegrind.

    SPDX-FileCopyrightText: 2009 Josef Weidendorfer <Josef.Weidendorfer@gmx.de>

    SPDX-License-Identifier: GPL-2.0-only
*/

#include "toplevelbase.h"

TopLevelBase::~TopLevelBase()
{}
